#include<fstream>
#include<time.h>
#include<vector>
#include<iostream>
#include <sys/stat.h>

#include "MapReader.h"
#include "Learner.h"
#include "Generator.h"
#include "Clustering.h"

using namespace std;

//used in checking the playability of Loderunner maps
struct Node{
    char type;
    bool bottom;
    bool visited;
    int x;
    int y;
    bool up;
    bool down;
    bool left;
    bool right;
    vector<int> Adj;
};

//various evaluation metrics
int FindBadPipes(string filename);
bool IsGroundMisplaced(string MapName);
double ComputeLinearity(string MapFile, string PointsFile);
double ComputeLeniency(string MapFile);

bool LoderunnerPlayable(string FileName);
int CountPlayers(string FileName);
bool KidIcarusPlayability(string Folder, string MapName);

//trains an MdMC on the provided training data, and then samples new maps using the trained model
void MdMCExperiments(string trainingFolderName, string trainingMapName, string outputFolderName, string outputMapName, int rowSplits, int lookAhead, int networkStructure, int trainingMaps, int toGenerate, int height, int width);

//uses the manually defined functions (only developed for mario) to convert low-level maps into high-level representations
void ManualConversion(string inputMapFolder, string outputMapFolder, string mapName, int numberOfMaps, int widthOfHighLevelTiles, int heightOfHighLevelTiles);

//used to cluster chunks of maps together in order to find high-level tiles, then converts low-level maps into their high-level representation
void ClusterAndConvert(string lowLevelMapFolder, string lowLevelMapName, int numberOfTrainingMaps, int widthOfHighLevelTiles, int heightOfHighLevelTiles, int numberOfClusters, float(*comparisonFunction) (vector< vector< char > >, vector< vector< char> >, vector< vector <float> >, vector<char>, int, int), string comparisonFunctionName);

//used for both hierarchical models (manually converted maps and clustering-based)
void TrainAndSample(string trainingMapFolder, string highLevelMapFolder, string mapName, string outputMapFolder, string highLevelOutputMapName, string lowLevelOutputMapName, int numberOfTrainingMaps, int widthOfHighLevelTiles, int heightOfHighLevelTiles, int numberOfOutputMaps, int widthOfHighLevelOutputMap, int heightOfHighLevelOutputMap, int highLevelDependencyMatrix, int lowLevelDependencyMatrix, int topLevelRowSplits, int highLevelLookAhead, int lowLevelLookAhead, bool manualConversion);



int main(int argc, char* argv[]){
    
    
    //MdMCExperiments("KidIcarus_Maps/","kidicarus_", "TestMaps/","kidicarus_", 50, 2, 3, 6, 10, 170, 16);
    
    MdMCExperiments("Mario_Maps/Standard/","mario_", "TestMaps/","mario_", 12, 3, 1, 16, 100, 12, 210);
    
    
    //ClusterAndConvert("Loderunner_Maps/", "Level ", 150, 10, 10, 8, &Direct, "Direct");
    //TrainAndSample("Loderunner_Maps/", "8-10X10-Direct/", "Level ", "TestMaps/", "HighLevel_", "LowLevel_", 150, 10, 10, 50, 3, 2, 2, 3, 1, 3, 5, false);
    
    
    //ManualConversion("Mario_Maps/", "Manual_3X3/", "mario_", 16, 3, 3);
    //TrainAndSample("Mario_Maps/", "Manual_3X3/", "mario_", "TestMaps/", "HighLevel_", "LowLevel_", 16, 3, 3, 50, 70, 4, 2, 3, 1, 3, 5, true);
    
    
   
    return 0;
}

bool KidIcarusPlayability(string Folder, string MapName){
    ifstream input(Folder+MapName);
    if(input.fail())
        cout<<"Couldnt open"<<endl;
    //read in the map
    vector< vector<char> > Map;
    string line;
    while(getline(input, line)){
        vector<char> tmp;
        for(int i=0; i<line.length(); i++){
            tmp.push_back(line.at(i));
        }
        Map.push_back(tmp);
        tmp.clear();
    }
    input.close();
    //mark the bottom spots as reachable
    for(int i=(int)Map.size()-1; i> Map.size()-10; i--){
        for(int j=0; j<Map[i].size(); j++){
            if((Map[i][j] == '#' || Map[i][j] == 'T' ) && Map[i-1][j] == '-')
                Map[i][j] = 'R';
        }
    }
    
    for(int i=0; i<5; i++){
        for(int h=(int)Map.size()-1; h>8; h--){
            //going to the right
            for(int w=0; w<Map[h].size(); w++){
                //if the space is reachable, determine what else could be reached from it
                if(Map[h][w] == 'R'){
                    for(int h1=-3; h1<=3; h1++){
                        if((h-h1) >=Map.size())
                            continue;
                        for(int w1= 0; w1<=4; w1++){
                            int tmpW1 = w+w1;
                            if(tmpW1 >= Map[h-h1].size())
                                tmpW1 =tmpW1 - (int)Map[h-h1].size();

                            if((Map[h-h1][tmpW1] == 'T' || Map[h-h1][tmpW1] == '#' || Map[h-h1][tmpW1] == 'M' || Map[h-h1][tmpW1] == 'R') && Map[h-h1-1][tmpW1] == '-' && (Map[h-h1-1][tmpW1-1] != '#' && Map[h-h1-1][tmpW1-1] != 'H'))
                                Map[h-h1][tmpW1] = 'R';
                        
                        }
                    }
                }
            }
            //going to the left
            for(int w=(int)Map[h].size()-1; w>=0; w--){
                //if the space is reachable, determine what else could be reached from it
                if(Map[h][w] == 'R'){
                    for(int h1=-3; h1<=3; h1++){
                        if((h-h1) >=Map.size())
                            continue;
                        for(int w1= 0; w1<=4; w1++){
                            int tmpW2 = w-w1;
                            if(tmpW2 < 0)
                                tmpW2 = (int)Map[h-h1].size()+tmpW2;
                        
                            if((Map[h-h1][tmpW2] == 'T' || Map[h-h1][tmpW2] == '#' || Map[h-h1][tmpW2] == 'M' || Map[h-h1][tmpW2] == 'R') && Map[h-h1-1][tmpW2] == '-' && (Map[h-h1-1][tmpW2+1] != '#' && Map[h-h1-1][tmpW2+1] != 'H'))
                                Map[h-h1][tmpW2] = 'R';
                        }
                    }
                }
            }
            //going to the right a second time
            for(int w=0; w<Map[h].size(); w++){
                //if the space is reachable, determine what else could be reached from it
                if(Map[h][w] == 'R'){
                    for(int h1=-3; h1<=3; h1++){
                        if((h-h1) >=Map.size())
                            continue;
                        for(int w1= 0; w1<=4; w1++){
                            int tmpW1 = w+w1;
                            if(tmpW1 >= Map[h-h1].size())
                                tmpW1 =tmpW1 - (int)Map[h-h1].size();
                        
                            if((Map[h-h1][tmpW1] == 'T' || Map[h-h1][tmpW1] == '#' || Map[h-h1][tmpW1] == 'M' || Map[h-h1][tmpW1] == 'R') && Map[h-h1-1][tmpW1] == '-' && (Map[h-h1-1][tmpW1-1] != '#' && Map[h-h1-1][tmpW1-1] != 'H'))
                                Map[h-h1][tmpW1] = 'R';
                        
                        }
                    }
                }
            }
            //going to the left a second time
            for(int w=(int)Map[h].size()-1; w>=0; w--){
                //if the space is reachable, determine what else could be reached from it
                if(Map[h][w] == 'R'){
                    for(int h1=-3; h1<=3; h1++){
                        if((h-h1) >=Map.size())
                            continue;
                        for(int w1= 0; w1<=4; w1++){
                            int tmpW2 = w-w1;
                            if(tmpW2 < 0)
                                tmpW2 = (int)Map[h-h1].size()+tmpW2;
                        
                            if((Map[h-h1][tmpW2] == 'T' || Map[h-h1][tmpW2] == '#' || Map[h-h1][tmpW2] == 'M' || Map[h-h1][tmpW2] == 'R') && Map[h-h1-1][tmpW2] == '-' && (Map[h-h1-1][tmpW2+1] != '#' && Map[h-h1-1][tmpW2+1] != 'H'))
                                Map[h-h1][tmpW2] = 'R';
                        }
                    }
                }
            }
        }
    }
    /*for(int i=0; i<Map.size(); i++){
        for(int j=0; j<Map[i].size(); j++)
            cout<<Map[i][j];
        cout<<endl;
    }*/
    
    for(int h=0; h<10; h++){
        for(int w=0; w<Map[h].size(); w++){
            if(Map[h][w] == 'R')
                return true;
        }
    }
    return false;
}

void MdMCExperiments(string trainingFolderName, string trainingMapName, string outputFolderName, string outputMapName, int rowSplits, int lookAhead, int networkStructure, int trainingMaps, int toGenerate, int height, int width){
    
    Learner TopLevelLearner = Learner(rowSplits, lookAhead, false, false);
    TopLevelLearner.FindAllTileTypes(trainingMaps, trainingFolderName+trainingMapName, false);
    
    
    for(int i=networkStructure; i>=0; i--)
        TopLevelLearner.SetDepMatrix(i);

    TopLevelLearner.SetRows(false);
    TopLevelLearner.ResizeVectors(false);
    
    //initializes the files necessary for storing the probabilities and totals
    for (int i = 0; i < TopLevelLearner.Config.NumberMatrices; i++)
        TopLevelLearner.InitFiles("HighLevel_Totals_Dep"+ to_string(i)+".txt", "", "HighLevel_Probabilities_Dep"+ to_string(i)+".txt", "", false, i);

    //records the encountered totals for each tile type
    for (int dep = 0; dep < TopLevelLearner.Config.NumberMatrices; dep++){
        TopLevelLearner.SetTotalsTopLevel(trainingFolderName+trainingMapName, trainingMaps, "HighLevel_Totals_Dep"+ to_string(dep)+".txt", false, dep);
    }

    //sets the probabilities using the totals
    for (int dep = 0; dep < TopLevelLearner.Config.NumberMatrices; dep++)
        TopLevelLearner.SetProbsForOnlyLowLevel("HighLevel_Probabilities_Dep" + to_string(dep) + ".txt", false, dep);

    Generator TopGen = Generator(width, height);
    TopGen.CopyConfig(TopLevelLearner.Config);
    TopGen.SetTileTypes(TopLevelLearner.TileTypes, false);
    TopGen.ResizeVectors(false);
    
    for (int dep = 0; dep < TopGen.Config.NumberMatrices; dep++)
        TopGen.CopyProbs("HighLevel_Probabilities_Dep"+ to_string(dep) +".txt", false, dep);
    
    #if defined(_WIN32)
        _mkdir(outputFolderName);
    #else
        mkdir(outputFolderName.c_str(), 0777);
    #endif
    
    clock_t start;
    start = clock();
    for (int i = 0; i < toGenerate; i++)
        TopGen.GenerateTopLevel(outputFolderName+outputMapName + to_string(i) + ".txt", i);
    cout << "Time in ms taken to generate all levels: " << (clock() - start) / (double)(CLOCKS_PER_SEC / 1000.0) << " ms" << endl;
    
}

void ClusterAndConvert(string lowLevelMapFolder, string lowLevelMapName, int numberOfTrainingMaps, int widthOfHighLevelTiles, int heightOfHighLevelTiles, int numberOfClusters, float(*comparisonFunction) (vector< vector< char > >, vector< vector< char> >, vector< vector <float> >, vector<char>, int, int), string comparisonFunctionName){

    Learner tileFinder = Learner(1, 0, true, false);
    tileFinder.FindAllTileTypes(numberOfTrainingMaps, lowLevelMapFolder+lowLevelMapName, false);
    
    
    //first we collect all the chunks of the training maps that are of the proper size
    MapReader Gatherer = MapReader();
    Gatherer.GatherAllBlocks(lowLevelMapFolder, lowLevelMapName, numberOfTrainingMaps, widthOfHighLevelTiles, heightOfHighLevelTiles);
    Clustering Clusterer = Clustering(widthOfHighLevelTiles, heightOfHighLevelTiles);
    
    //we then remove all the duplicate chunks, so as to speed up clustering
    Clusterer.RemoveDuplicates(lowLevelMapFolder,to_string(widthOfHighLevelTiles)+"X"+to_string(heightOfHighLevelTiles)+"_Blocks.txt");
    
    //next, compute the distances between each of the chunks using the desired comparisonFunction
    Clusterer.ComputeDifferences(lowLevelMapFolder+"Duplicates_Removed_"+to_string(widthOfHighLevelTiles)+"X"+to_string(heightOfHighLevelTiles)+"_Blocks.txt", lowLevelMapFolder+comparisonFunctionName+"_Differences_"+to_string(widthOfHighLevelTiles)+"X"+to_string(heightOfHighLevelTiles)+".csv", comparisonFunction, vector<vector<float>>(), tileFinder.TileTypes);
     

    //Perform k-Medoids Clustering on the collected chunks, using the computed distance matrix
    string DifferenceFile = lowLevelMapFolder+comparisonFunctionName+"_Differences_"+to_string(widthOfHighLevelTiles)+"X"+to_string(heightOfHighLevelTiles)+".csv";
    Clusterer.kMedoids(DifferenceFile, numberOfClusters);
    Clusterer.PrintMedoids(lowLevelMapFolder+"Duplicates_Removed_"+to_string(widthOfHighLevelTiles)+"X"+to_string(heightOfHighLevelTiles)+"_Blocks.txt", lowLevelMapFolder+comparisonFunctionName+"_Medoids_"+to_string(numberOfClusters)+"_"+to_string(widthOfHighLevelTiles)+"X"+to_string(heightOfHighLevelTiles)+".txt");
    
    //convert the low-level training maps into high-level training maps using the found cluster medoids
    vector<vector<vector<char> > > Medoids;
    
    //read in the medoids (high-level tiles)
    ifstream Medoid_File;
    string line;
    Medoid_File.open(lowLevelMapFolder+comparisonFunctionName+"_Medoids_"+to_string(numberOfClusters)+"_"+to_string(widthOfHighLevelTiles)+"X"+to_string(heightOfHighLevelTiles)+".txt");
     
    while(!getline(Medoid_File, line).eof()){
        vector<vector< char > > Block;
        for(int h = 0; h < heightOfHighLevelTiles; h++){
            getline(Medoid_File, line);
            vector< char > temp;
            for(int w=0; w<widthOfHighLevelTiles; w++)
                temp.push_back(line.at(w));
     
            Block.push_back(temp);
        }
        getline(Medoid_File, line);
        Medoids.push_back(Block);
    }
    
    //output maps folder
    string OutputFolder = lowLevelMapFolder+to_string(numberOfClusters)+"-"+to_string(widthOfHighLevelTiles)+"X"+to_string(heightOfHighLevelTiles)+"-"+comparisonFunctionName;
    
    #if defined(_WIN32)
        _mkdir(OutputFolder.c_str());
    #else
        mkdir(OutputFolder.c_str(), 0777);
    #endif
    
    //convert the low-level maps into high-level maps, and put them in the newly created subfolder
    MapReader Converter = MapReader();
    Converter.ConvertAllTileMapsToHier(lowLevelMapName, lowLevelMapFolder, OutputFolder+"/", numberOfTrainingMaps, widthOfHighLevelTiles, heightOfHighLevelTiles, Medoids, comparisonFunction, comparisonFunctionName, vector<vector<float>>(), tileFinder.TileTypes);
    Medoid_File.close();
    Medoids.clear();
}

void ManualConversion(string inputMapFolder, string outputMapFolder, string mapName, int numberOfMaps, int widthOfHighLevelTiles, int heightOfHighLevelTiles){
    
    #if defined(_WIN32)
        _mkdir((inputMapFolder+outputMapFolder).c_str());
    #else
        mkdir((inputMapFolder+outputMapFolder).c_str(), 0777);
    #endif
    
    MapReader Converter;
    Converter.ConvertAllTileMapsToHier(inputMapFolder+mapName, inputMapFolder+outputMapFolder+mapName, numberOfMaps, widthOfHighLevelTiles, heightOfHighLevelTiles);
}


void TrainAndSample(string trainingMapFolder, string highLevelMapFolder, string mapName, string outputMapFolder, string highLevelOutputMapName, string lowLevelOutputMapName, int numberOfTrainingMaps, int widthOfHighLevelTiles, int heightOfHighLevelTiles, int numberOfOutputMaps, int widthOfHighLevelOutputMap, int heightOfHighLevelOutputMap, int highLevelDependencyMatrix, int lowLevelDependencyMatrix, int topLevelRowSplits, int highLevelLookAhead, int lowLevelLookAhead, bool manualConversion){
    
    //initialize the high-level training model
    Learner TopLevelLearner = Learner(topLevelRowSplits, highLevelLookAhead, false, true);
    TopLevelLearner.Config.width = widthOfHighLevelTiles;
    TopLevelLearner.Config.height = heightOfHighLevelTiles;
    
    //find all the high-level tie types from the high-level training maps
    TopLevelLearner.FindAllTileTypes(numberOfTrainingMaps, trainingMapFolder+highLevelMapFolder+mapName, true);
    
    
    //pushes the chosen dependency matrix as well as the subsequent fallback dependency matrices into the model for use
    for(int depMatrix = highLevelDependencyMatrix; depMatrix>=0; depMatrix--)
        TopLevelLearner.SetDepMatrix(depMatrix);
        
    //sets up the number of rows each probability table table will need, and resizes them accordingly
    TopLevelLearner.SetRows(true);
    TopLevelLearner.ResizeVectors(false);
    
    //for each dependency matrix, intialize the files used to store the porbabilities and totals
    for (int i = 0; i < TopLevelLearner.Config.NumberMatrices; i++)
        TopLevelLearner.InitFiles("HighLevel_Totals_Dep"+ to_string(i)+".txt", "", "HighLevel_Probabilities_Dep"+ to_string(i)+".txt", "", true, i);
    
    //train a separate probability table for each dependency matrix
    //performs the counting
    for (int dep = 0; dep < TopLevelLearner.Config.NumberMatrices; dep++){
        TopLevelLearner.SetTotalsTopLevel(trainingMapFolder + highLevelMapFolder + mapName, numberOfTrainingMaps, "HighLevel_Totals_Dep"+ to_string(dep)+".txt", true, dep);
    }
    
    //sets the probabilities according to the counts
    for (int dep = 0; dep < TopLevelLearner.Config.NumberMatrices; dep++)
        TopLevelLearner.SetProbs("HighLevel_Probabilities_Dep" + to_string(dep) + ".txt", true, dep);
     
    
    //initialize the low-level training model
    Learner BottomLevelLearner = Learner(1, lowLevelLookAhead, false, false);
    BottomLevelLearner.Config.width = widthOfHighLevelTiles;
    BottomLevelLearner.Config.height = heightOfHighLevelTiles;
    
    //find all the high-level tile types, and low-level tile types
    BottomLevelLearner.FindAllTileTypes(numberOfTrainingMaps, trainingMapFolder+highLevelMapFolder+mapName, true);
    BottomLevelLearner.FindAllTileTypes(numberOfTrainingMaps, trainingMapFolder+mapName, false);
    
    //set the dependency matrix and the fallback dependency matrices
    for(int depMatrix = lowLevelDependencyMatrix; depMatrix>=0; depMatrix--)
        BottomLevelLearner.SetDepMatrix(depMatrix);
    
    //determine the number of rows each probability table needs, and resize them accordingly
    BottomLevelLearner.SetRows(false);
    BottomLevelLearner.ResizeVectors(true);
     
    //initialize the files used for storing the totals and probabilities for the low-level model
    for (int i = 0; i < BottomLevelLearner.Config.NumberMatrices; i++)
        BottomLevelLearner.InitFiles("", "LowLevel_Totals" + to_string(i) + ".txt", "", "LowLevel_Probabilities" + to_string(i) + ".txt", false, i);
    
    //train a separate model for each high-level tile type, and for each dependency matrix
    for (int dep = 0; dep < BottomLevelLearner.Config.NumberMatrices; dep++){
        for (int i = 1; i <=numberOfTrainingMaps; i++)
            BottomLevelLearner.SetTotalsBottomLevel(trainingMapFolder+highLevelMapFolder+mapName+to_string(i) + ".txt", trainingMapFolder+mapName+to_string(i) + ".txt", "LowLevel_Totals"+ to_string(dep) + ".txt", dep, manualConversion);
    }
    
    //set the probabilities according to the observed totals
    for (int dep = 0; dep < BottomLevelLearner.Config.NumberMatrices; dep++)
        BottomLevelLearner.SetProbs("LowLevel_Probabilities"+ to_string(dep) +".txt", false, dep);
    
    //initialize the high-level map generator
    Generator TopGen = Generator(widthOfHighLevelOutputMap, heightOfHighLevelOutputMap);
    TopGen.CopyConfig(TopLevelLearner.Config);
    TopGen.SetTileTypes(TopLevelLearner.HierTileTypes, false);
    TopGen.ResizeVectors(false);
    
    //copy the probabilities from the probability file
    for (int dep = 0; dep < TopGen.Config.NumberMatrices; dep++)
        TopGen.CopyProbs("HighLevel_Probabilities_Dep"+ to_string(dep) +".txt", false, dep);
    
    //initialize the low-level map generator
    Generator BottomGen = Generator(widthOfHighLevelOutputMap*widthOfHighLevelTiles, heightOfHighLevelOutputMap*heightOfHighLevelTiles);
    BottomGen.CopyConfig(BottomLevelLearner.Config);
    BottomGen.SetTileTypes(BottomLevelLearner.TileTypes, false);
    BottomGen.SetTileTypes(BottomLevelLearner.HierTileTypes, true);
    BottomGen.ResizeVectors(true);
    BottomGen.Config.NumberMatrices = BottomLevelLearner.Config.NumberMatrices;
     
    for (int dep = 0; dep < BottomGen.Config.NumberMatrices; dep++)
        BottomGen.CopyProbs("LowLevel_Probabilities"+ to_string(dep) +".txt", true, dep);
    
    //crate the directory to store the maps if one does not already exist
    #if defined(_WIN32)
        _mkdir(outputMapFolder.c_str());
    #else
        mkdir(outputMapFolder.c_str(), 0777);
    #endif

    clock_t    start;
    start = clock();
    for (int i = 0; i < numberOfOutputMaps; i++)
        TopGen.GenerateTopLevel(outputMapFolder+highLevelOutputMapName+to_string(i)+".txt", i);
    
    for (int i = 0; i < numberOfOutputMaps; i++)
        BottomGen.GenerateBottomLevel(outputMapFolder+lowLevelOutputMapName + "BottomLevel " + to_string(i) + ".txt",
    outputMapFolder + highLevelOutputMapName + to_string(i) + ".txt", i, manualConversion);
    cout << "Time: " << (clock() - start) / (double)(CLOCKS_PER_SEC / 1000.0) << " ms" << endl;
}


double ComputeLeniency(string MapFile){
    
    ifstream input(MapFile.c_str());
    
    //read in the map
    vector<vector<char>> Map;
    string line;
    while(!getline(input, line).eof()){
        vector<char> row;
        for(int i=0; i<line.length(); i++){
            row.push_back(line.at(i));
        }
        Map.push_back(row);
    }
    
    /*vector<char> row;
    for(int i=0; i<line.length(); i++){
        row.push_back(line.at(i));
    }
    Map.push_back(row);
    */
    int prevHeight=0;
    float Leniency=0;
    for(int w=0; w<Map[0].size()-1; w++){
        
        if(Map[Map.size()-1][w] == '-'){
            bool covered=false;
            for(int h=(int)Map.size()-2; h>0; h--){
                if(Map[h][w] != '-' && Map[h-1][w] == '-' && h > prevHeight-2){
                    covered = true;
                    prevHeight=h;
                    break;
                }
            }
            if(!covered)
                Leniency++;
        } else{
            for(int h=0; h<Map.size(); h++){
                if(Map[h][w] !='-' && h >= prevHeight-3){
                    prevHeight = h;
                    break;
                }
            }
        }
        
    }
    
    return Leniency;
}

int CountPlayers(string FileName){
    
    ifstream Input(FileName.c_str());
    string line;
    int NumPlayers =0;
    while(!getline(Input, line).eof()){
        for(int i=0; i<line.length(); i++){
            if(line.at(i) == 'M')
                NumPlayers++;
        }
    }
    return NumPlayers;
}

void CreateGraph(vector<vector<Node>> &Map, string FileName){
    
    ifstream InputMap(FileName.c_str());
    
    string line;
    while(!getline(InputMap, line).eof()){
        vector<Node> Row;
        for(int j=0; j<line.length(); j++){
            Node cell;
            cell.up     = false;
            cell.down   = false;
            cell.left   = false;
            cell.right  = false;
            cell.type = line.at(j);
            //cout<<cell.type;
            cell.visited = false;
            Row.push_back(cell);
        }
        //cout<<endl;
        Map.push_back(Row);
    }
    InputMap.close();
    
    for(int h=0; h<Map.size(); h++){
        for(int w=0; w<Map[h].size(); w++){
            Map[h][w].x = w;
            Map[h][w].y = h;
            if(h == Map.size()-1)
                Map[h][w].bottom = true;
            
            //check the current type and the type of the surrounding tiles
            //if empty (or essentially empty (gold, player, enemy, empty)
            if(Map[h][w].type == '.' || Map[h][w].type == 'M' || Map[h][w].type == 'E' || Map[h][w].type == 'G'){
                //check if standing on something solid or it is the bottom tile (we assume a row of solid tiles under)
                if(Map[h][w].bottom || Map[h+1][w].type == 'b' || Map[h+1][w].type == 'B' || Map[h+1][w].type == '#'){
                    //check if anything blocking to the left
                    if(w > 0 && Map[h][w-1].type != 'b' && Map[h][w-1].type != 'B')
                        Map[h][w].left = true;
                    
                    //check if anything blocking to the right
                    if(w < Map[h].size()-1 && Map[h][w+1].type != 'b' && Map[h][w+1].type != 'B')
                        Map[h][w].right = true;
                    
                    //standing on a diggable tile, and something solid to the left of it
                    if(!Map[h][w].bottom && w > 0 && (Map[h+1][w-1].type == 'b' || Map[h+1][w-1].type == 'B'))
                        Map[h][w].down = true;
                    
                    //standing on a diggable tile, and something solid to the right of it
                    if(!Map[h][w].bottom && w < Map[h].size()-1 && (Map[h+1][w+1].type == 'b' || Map[h+1][w+1].type == 'B'))
                        Map[h][w].down = true;
                }
                //if not standing on something solid, then fall
                else if(!Map[h][w].bottom && Map[h+1][w].type != 'b' && Map[h+1][w].type != 'B' && Map[h+1][w].type != '#')
                    Map[h][w].down = true;
                
            } else if(Map[h][w].type == '#'){   //if on a ladder
                //if nothing solid above, move up
                if(h > 0 && Map[h-1][w].type != 'b' && Map[h-1][w].type != 'B')
                    Map[h][w].up = true;
                
                //if nothing below, move down
                if(!Map[h][w].bottom && Map[h+1][w].type != 'b' && Map[h+1][w].type != 'B')
                    Map[h][w].down = true;
                
                //if nothing left, move left
                if(w > 0 && Map[h][w-1].type != 'b' && Map[h][w-1].type != 'B')
                    Map[h][w].left = true;
                
                //if nothing right, move right
                if(w < Map[h].size()-1 && Map[h][w+1].type != 'b' && Map[h][w+1].type != 'B')
                    Map[h][w].right = true;
            } else if(Map[h][w].type == 'b'){    //in a diggable block
                //standing on a diggable tile, and something solid to the left of it
                if(!Map[h][w].bottom && w > 0 && (Map[h][w-1].type == 'b' || Map[h][w-1].type == 'B'))
                    Map[h][w].down = true;
                
                //standing on a diggable tile, and something solid to the right of it
                if(!Map[h][w].bottom && w < Map[h].size()-1 && (Map[h][w+1].type == 'b' || Map[h][w+1].type == 'B'))
                    Map[h][w].down = true;
            } else if(Map[h][w].type == '-'){   //on a rope
                //if nothing below, move down
                if(!Map[h][w].bottom && Map[h+1][w].type != 'b' && Map[h+1][w].type != 'B')
                    Map[h][w].down = true;
                
                //if nothing left, move left
                if(w > 0 && Map[h][w-1].type != 'b' && Map[h][w-1].type != 'B')
                    Map[h][w].left = true;
                
                //if nothing right, move right
                if(w < Map[h].size()-1 && Map[h][w+1].type != 'b' && Map[h][w+1].type != 'B')
                    Map[h][w].right = true;
            }
        }
    }
}

void PrintGraph(vector<vector<Node>> Map){
    
    ofstream Traversal("Traversal.txt");
    Traversal<<"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"<<endl;
    
    for(int i=0; i<Map.size(); i++){
        //moving up
        for(int j=0; j<Map[i].size(); j++){
            if(j>0)
                Traversal<<"  ";
            if(Map[i][j].up)
                Traversal<<"^";
            else
                Traversal<<" ";
        }
        Traversal<<endl;
        
        //left right movement
        for(int j=0; j<Map[i].size(); j++){
            
            if(j==0){
                Traversal<<Map[i][j].type;
                if(Map[i][j].right)
                    Traversal<<">";
                else
                    Traversal<<" ";
            } else{
                if(Map[i][j].left)
                    Traversal<<"<";
                else
                    Traversal<<" ";
                Traversal<<Map[i][j].type;
                if(Map[i][j].right)
                    Traversal<<">";
                else
                    Traversal<<" ";
            }
        }
        Traversal<<endl;
        //moving down
        for(int j=0; j<Map[i].size(); j++){
            if(j>0)
                Traversal<<"  ";
            if(Map[i][j].down)
                Traversal<<"v";
            else
                Traversal<<" ";
        }
        Traversal<<endl;
    }
    
    Traversal<<"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"<<endl;
    Traversal.close();
}

void CheckReachability(vector<vector< Node>> Map){
    
    vector< vector< bool> > Reachability;

    //Now I need to try to travel from each of the treasures to the others
    //gather the gold bar positions
    vector<vector<int>> GoldPositions;
    for(int i=0; i<Map.size(); i++){
        for(int j=0; j<Map[i].size(); j++){
            if(Map[i][j].type == 'G'){
                vector<int> pos;
                pos.push_back(i);
                pos.push_back(j);
                GoldPositions.push_back(pos);
            }
        }
    }
    
    //for each pair of gold bars, determine in on is reachable from the other
    Reachability.resize(GoldPositions.size());
    for(int i=0; i<Reachability.size(); i++)
        Reachability[i].resize(GoldPositions.size());
    
    //cout<<GoldPositions[0][0]<<" "<<GoldPositions[0][1]<<endl;
    //cout<<GoldPositions[1][0]<<" "<<GoldPositions[1][1]<<endl;
    
    for(int start = 0; start < GoldPositions.size(); start++){
        for(int end = 0; end < GoldPositions.size(); end++){
            
            //perform depth first search to check if gold is reachable
            if(start == end){
                //ignore the trivial path to itself
                Reachability[start][end] = false;
                continue;
            }
            vector<Node> stack;
            //push back the starting node, and mark it as visited
            //Map[GoldPositions[start][0]][GoldPositions[start][1]].visited = true;
            stack.push_back(Map[GoldPositions[start][0]][GoldPositions[start][1]]);
            
            //while that stack is not empty
            //or until a path is found
            //cout<<stack.size()<<endl;
            bool found = false;
            
            
            
            while(!stack.empty()){
                if(stack.back().x == GoldPositions[end][1] && stack.back().y == GoldPositions[end][0]){
                    found = true;
                    break;
                }
                Node curr;
                Map[stack.back().y][stack.back().x].visited = true;
                curr.x = stack.back().x;
                curr.y = stack.back().y;
                curr.left = stack.back().left;
                curr.right= stack.back().right;
                curr.up = stack.back().up;
                curr.down = stack.back().down;
                curr.type = stack.back().type;
                curr.bottom = stack.back().bottom;
                curr.visited = true;
                
                //cout<<curr.x<<" "<<curr.y<<" "<<curr.type<<" "<<curr.visited<<endl;
                stack.pop_back();
                
                //stack.erase(stack.begin());
                
                //push all children fo the current node
                if(curr.left && Map[curr.y][curr.x-1].visited == false){
                    //Map[curr.y][curr.x-1].visited =true;
                    stack.push_back(Map[curr.y][curr.x-1]);
                }
                //cout<<curr.x<<" "<<curr.y<<" "<<curr.type<<" "<<curr.visited<<endl;
                if(curr.down && Map[curr.y+1][curr.x].visited == false){
                    //Map[curr.y+1][curr.x].visited =true;
                    stack.push_back(Map[curr.y+1][curr.x]);
                }
                //cout<<curr.x<<" "<<curr.y<<" "<<curr.type<<" "<<curr.visited<<endl;
                if(curr.right && Map[curr.y][curr.x+1].visited == false){
                    //Map[curr.y][curr.x+1].visited =true;
                    stack.push_back(Map[curr.y][curr.x+1]);
                }
                //cout<<curr.x<<" "<<curr.y<<" "<<curr.type<<" "<<curr.visited<<endl;
                if(curr.up && Map[curr.y-1][curr.x].visited == false){
                    //Map[curr.y-1][curr.x].visited =true;
                    stack.push_back(Map[curr.y-1][curr.x]);
                }
                
            }
            
            Reachability[start][end] = found;
            for (int q=0; q<Map.size(); q++) {
                for(int t=0; t<Map[q].size(); t++){
                    Map[q][t].visited = false;
                }
            }
        }
    }
    ofstream Reach("Reachability.txt");
    for(int i=0; i<Reachability.size(); i++){
        for(int j=0; j<Reachability[i].size(); j++){
            //cout<<Reachability[i][j]<<" ";
            Reach<<Reachability[i][j];
        }
        //cout<<endl;
        Reach<<endl;
    }
    //cout<<endl;
    Reach<<endl;
    //cout<<"After CheckReachability"<<endl;

}

bool FindPath(string inputfile){
    
    vector<vector<bool> > Reach;
    ifstream input(inputfile.c_str());
    
    string line;
    while(!getline(input, line).eof()){
        vector<bool> tmp;
        for(int i=0; i<line.length(); i++){
            //cout<<"X"<<line.at(i)<<"X"<<endl;
            if(line.at(i) == '0'){
                tmp.push_back(false);
                //cout<<"In false"<<endl;
            }
            else if(line.at(i) == '1'){
                tmp.push_back(true);
                //cout<<"In true"<<endl;
            }
        }
        if(tmp.size() != 0)
            Reach.push_back(tmp);
        
    }
    
    /*for(int i=0; i<Reach.size(); i++){
        for(int j=0; j<Reach[i].size(); j++)
            cout<<Reach[i][j]<<" ";
        cout<<endl;
        
    }*/
    
    
    vector<Node> Golds;
    //cout<<"REACH SIZE "<<Reach.size()<<endl;
    //initialize the nodes of the graph
    for(int i=0; i<Reach.size(); i++){
        Node tmp;
        tmp.x = i;
        Golds.push_back(tmp);
    }
    
    //build the edges of the graph
    for(int i=0; i<Golds.size(); i++){
        Golds[i].visited = false;
        for(int j=0; j<Reach[i].size(); j++){
            if(Reach[i][j])
                Golds[i].Adj.push_back(j);
        }
    }
    
    //perform depth-first search to check for playability
    //check from each starting point
    for(int i=0; i<Golds.size(); i++){
        vector<Node> DFSstack;
        DFSstack.push_back(Golds[i]);
        
        bool found = false;
        
        while(!DFSstack.empty()){
            
            bool all_visited=true;
            for(int j=0; j<Golds.size(); j++){
                if(!Golds[j].visited){
                    all_visited = false;
                    break;
                }
            }
            if(all_visited){
                found = true;
                break;
            }
            
            DFSstack.back().visited =true;
            Node curr;
            for(int j=0; j<DFSstack.back().Adj.size(); j++)
                curr.Adj.push_back(DFSstack.back().Adj[j]);
            
            curr.visited = true;
            curr.x = DFSstack.back().x;
            Golds[curr.x].visited = true;
            
            //cout<<"Current Gold "<<curr.x<<endl;
            DFSstack.pop_back();
            
            //push all children of the current node
            for(int j=0; j<curr.Adj.size(); j++){
                if(!Golds[curr.Adj[j]].visited)
                    DFSstack.push_back(Golds[curr.Adj[j]]);
            }
            //cout<<DFSstack.size()<<endl;
        }
        
        DFSstack.clear();
        for(int j=0; j<Golds.size(); j++){
            //cout<<Golds[j].visited<<" ";
            Golds[j].visited = false;
        }
        //cout<<endl;
        
        //if a path is found, return
        if(found){
            //cout<<"FOUND"<<endl;
            return true;
        }
    }
    //cout<<"NOT FOUND"<<endl;
    return false;
}

bool LoderunnerPlayable(string FileName){
    
    vector<vector<Node>> Map;
    CreateGraph(Map, FileName);
    //PrintGraph(Map);
    CheckReachability(Map);
    
    return FindPath("Reachability.txt");
}

bool IsGroundMisplaced(string MapName){
	
	ifstream Input;
	Input.open(MapName.c_str());

	vector< vector< char> > Map;
	vector<char> tmp;
	string line = "";
	while (getline(Input, line)){
		for (int i = 0; i < line.size(); i++){
			tmp.push_back(line.at(i));
		}
		Map.push_back(tmp);
		tmp.clear();
	}
	for (int i = 0; i < Map.size(); i++){
		for (int j = 0; j < Map.at(0).size(); j++){
			if ((Map[i][j] == 'G' || Map[i][j] == 'A') && i != Map.size() - 1)
				return true;
		}
	}

	Input.close();
	return false;
}

int FindBadPipes(string filename){
	ifstream map;
	map.open(filename.c_str());
	string line1;
	string line2;

	char curr;
	char right;
	char under;
	char left;
	map>>line1;
	int BadPipes=0;
	for(int y=0; y<13; y++){
		map>>line2;
		curr = 'X';
		right= 'X';
		under= 'X';
		left = 'X';
		for(int x=0; x<210; x++){
			if(line1.at(x) == 'p' || line1.at(x) == 'P'){
				curr = line1.at(x);
				if(y<13)
					under = line2.at(x);
				if(x<209)
					right = line1.at(x+1);
				if(x>0)
					left = line1.at(x-1);

				//by putting all the bad options in one if statement, if a pipe is bad in multiple ways, it only gets counted once
				if((curr == 'p' && x < 209 && right != 'P') ||					//right pipe did not follow left pipe
					(curr == 'p' && y < 13 && under != 'p' && under != '#') ||	//left pipe is floating, or on invalid piece
					(curr == 'P' && y < 13 && under != 'P' && under != '#') ||	//right pipe is floating or on invalid piece
					(curr == 'P' && x > 0  && left  != 'p')					||	//left pipe did not precede right pipe
					(y < 13 && (under == 'p' || under == 'P') && curr != '-' && curr != under)) //nonempty tile on top of pipe
						BadPipes++;
			}
			else
				continue;
		}
		line1 =line2;
	}

	return BadPipes;
}
