#include "Generator.h"
#include <math.h>
#include <fstream>
#include <time.h>
#include <iostream>

int Generator::GenerateTopLevelTile(vector<char> PossibleTiles, int depth, int h, int w, int offset, vector< vector< int> > Method, int WhichDepMat){
	int id = -1;
    double selector;
    int type=START;
	vector<char> PT(PossibleTiles.size());	//create a copy of the possible tiles vector to use for changes
	vector<float> Probs;
	for (int i = 0; i<PossibleTiles.size(); i++)
		PT[i] = PossibleTiles[i];

	while (!PT.empty()){		//while there is still a possible tile
		int ID = 0;
		int P = 0;
		//check if this state has been observed before
		for (int k = 0; k<5; k++){
			for (int m = 2; m >= 0; m--){
				if (Method[k][m] == 1){
					if ((h + (k - 2) < 0) || (h + (k - 2) >= this->HeightOfLevel) || (w + (m - 2) < 0))
                        type = START;
					else{
						for (int b = 0; b < this->TileTypes.size(); b++){
							if (Map[h + (k - 2)][w + (m - 2)] == this->TileTypes.at(b))
								type = b;
						}
					}
					ID += type*pow(TileTypes.size(), P);
					P++;
				}
			}
		}

        bool Obs = false;
		//check if the state has been observed before
		for (int a = 0; a < PT.size(); a++){
			for (int x = 0; x < this->TileTypes.size(); x++){
				if (PT.at(a) == this->TileTypes.at(x)){
					if (this->Probabilities[WhichDepMat][ID+Config.Rows[WhichDepMat]*offset][x] != 0){
						Obs = true;
						x = (int)this->TileTypes.size();
						a = (int)PT.size();
					}
				}
			}
		}

		if (Obs != true && depth != this->Config.LookAhead){		//if this state hasnt been observed and this is NOT the top level in the lookahead
			this->BackTracks++;				//then return an error
			return 99;
		}
		else if (Obs != true && depth == this->Config.LookAhead){	//if we havent observed this state, and it IS the first step, then break out of
			break;								//of the loop, where we will return a random tile
		}
		else if (Obs == true){				//if we have observed this state, then generate the next tile
			float Norm = 0;
			Probs.resize(PT.size());
			for (int i = 0; i< PT.size(); i++)	//reset the value of Probs
				Probs[i] = 0;

			for (int a = 0; a < PT.size(); a++){
				for (int x = 0; x < this->TileTypes.size(); x++){
					if (PT.at(a) == this->TileTypes.at(x)){
						Probs[a] = this->Probabilities[WhichDepMat][ID+Config.Rows[WhichDepMat]*offset][x];
						Norm += this->Probabilities[WhichDepMat][ID+Config.Rows[WhichDepMat]*offset][x];
					}
				}
			}
			for (int i = 0; i<PT.size(); i++){						//renormalize the probabilities
				Probs[i] = Probs[i] / Norm;
			}

			//PICK THE TILE
			double PR = 0;
			int tracker = 0;
			selector = ((double)rand()/RAND_MAX);
			for (int a = 0; a<PT.size(); a++){
				PR = PR + Probs[a];
				if (Probs[a]>0)
					tracker = a;
				if (selector <= PR){
					id = a;
					break;
				}
				//if weirdness happens with the probabilities
				//BROKEN
                //if (a >= PT.size() - 1 && id == -1)
				//	id = tracker;
			}
			
			if (h < Map.size() && w < Map.at(0).size())
                Map[h][w] = PT[id];

			//call the GenTile function to generate the next tile
			//set to a test variable, so we can check the validity
			//of the next state
			int test = 1;

			if (depth > 0){
				if (w < this->LengthOfLevel-1)
					test = GenerateTopLevelTile(TileTypes, depth - 1, h, w+1, offset, Method, WhichDepMat);
            }
			//if the next state isnt valid, remove the tile chosen in this state and try a different one
			if (test == 99){
				int j = 0;
				if (id < PT.size()){
					for (vector<char>::iterator i = PT.begin(); i != PT.end(); i++){
						if (PT.at(j) == PT.at(id)){
							PT.erase(i);
							break;
						}
						j++;
					}
				}
				else
					PT.clear();
			}
			else{
				for (int i = 0; i < this->TileTypes.size(); i++){
					if (PT[id] == this->TileTypes[i])
						return i;
				}
			}
		}
	}									//end of loop

	if (depth == this->Config.LookAhead){				//if no valid options on top level, return error code 100
		return 100;
	}
	else{
		this->BackTracks++;
		return 99;				//if no valid options on sub level, return error.
	}							//forces a different choice on upper levels.
}

void Generator::GenerateTopLevel(string filename, int RandOffsetSeed){

	srand((unsigned)time(0) + RandOffsetSeed);
	START = 0;
    
	//initialize the set of possible tiles for this level
	vector<char> PossibleTiles(TileTypes.size());
	for (int i = 1; i < this->TileTypes.size(); i++)
		PossibleTiles[i]=TileTypes[i];

    //initialize the map to be generated
	this->Map.resize(this->HeightOfLevel);
	for (int i = 0; i < this->HeightOfLevel; i++){
		this->Map[i].resize(this->LengthOfLevel);
		for (int j = 0; j < this->LengthOfLevel; j++){
			this->Map[i][j] = 'X';
		}
	}

    int rowsPerSplit = (int)Map.size()/Config.Rowsplits;
    for (int h=(int)Map.size()-1; h>=0; h--){
        int currRow = h/rowsPerSplit;
        if(currRow >= Config.Rowsplits)
            currRow = Config.Rowsplits-1;
        for (int j = 0; j <Map[h].size(); j++){
                    
            //try to generate a tile with the first config matrix
            int id = GenerateTopLevelTile(PossibleTiles, this->Config.LookAhead, h, j, currRow, this->Config.DependencyMatrices[0], 0);
            //if it fails, and we are using a fallback strategy, try to generate with the second config matrix
            //if a good tile is generated with first method, track it
            if (id != 100){
                this->NumberTilesWithEachMatrix[0]++;
            }

            int WhichDepMat = 1;
            while (id == 100 && WhichDepMat < this->Config.NumberMatrices){

                id = GenerateTopLevelTile(PossibleTiles, this->Config.LookAhead, h, j, currRow, this->Config.DependencyMatrices[WhichDepMat], WhichDepMat);
                //track how many tiles generated with fallback method
                if (id != 100){
                    this->NumberTilesWithEachMatrix[WhichDepMat]++;
                    break;
                }
                else
                    WhichDepMat++;
            }

            //if it also fails, or we are not using a fallback strategy, generate a tile at random
            if (id == 100){
                //ignore one of the tiles
                while (id == 100 || (this->TileTypes[id] == START)){
                    id = (rand() % (this->TileTypes.size()-1)) + 1;
                }
            }
            Map[h][j] = this->TileTypes.at(id);
        }
    }
    //open the file to print the map into
	ofstream GMap;
	GMap.open(filename.c_str());
	for (int i = 0; i < this->Map.size(); i++){
		for (int j = 0; j < this->Map.at(0).size(); j++)
			GMap << this->Map[i][j];
		GMap << endl;
	}
}

int Generator::GenerateBottomLevelTile(vector<char> PossibleTiles, int depth, int h, int w, vector< vector< int> > Method, vector< vector< char> > HierMap, int WhichDepMat, bool manualConversion){
	int id = -1;
    double selector;
    int type =0;
	vector<char> PT;	//create a copy of the possible tiles vector to use for changes
	vector<float> Probs;
	Probs.resize(PT.size());
	for (int i = 1; i<PossibleTiles.size(); i++)
		PT.push_back(PossibleTiles.at(i));

    while (!PT.empty()){		//while there is still a possible tile
		int ID = 0;
		int P = 0;
		//check if this state has been observed before
		for (int k = 0; k<5; k++){
			for (int m = 2; m >= 0; m--){
				if (Method[k][m] == 1){
					if ((h + (k - 2) < 0) || (h + (k - 2) >= this->HeightOfLevel) || (w + (m - 2) < 0))
                        type = START;
					else{
						for (int b = 0; b < this->TileTypes.size(); b++){
							if (Map[h + (k - 2)][w + (m - 2)] == this->TileTypes.at(b))
								type = b;
						}
					}
					ID += type*pow(this->TileTypes.size(), P);
					P++;
				}
			}
		}

		bool Obs = false;

		int HierTile = -1;
		for (int i = 0; i < this->HierTileTypes.size(); i++){
            if (this->HierTileTypes[i] == HierMap[h / this->Config.height][w / this->Config.width]){
				HierTile = i;
				break;
			}
		}
        //deals with the fact that the last row of high level tiles only accounts for 1 row of low-level tiles
        if(manualConversion){
            if((this->HierTileTypes[HierTile] == 'G' || this->HierTileTypes[HierTile] == 'A') && h<(this->HeightOfLevel-1)){
                HierTile = HierMap[ceil((h/this->Config.height))][w/this->Config.width]-1;
            
                for (int i = 0; i < this->HierTileTypes.size(); i++){
                    if (this->HierTileTypes[i] == HierMap[(h / this->Config.height)][w / this->Config.width]){
                        HierTile = i;
                        //if equal to ground or gap (bottom row)
                        break;
                    }
                }
            }
        }
        
        //check if the state has been observed before
		for (int a = 0; a < PT.size(); a++){
			for (int x = 0; x < this->TileTypes.size(); x++){
				if (PT.at(a) == this->TileTypes.at(x)){
					if (this->HierProbabilities[WhichDepMat][HierTile][ID][x] != 0){
						Obs = true;
						x = (int)this->TileTypes.size();
						a = (int)PT.size();
					}
				}
			}
		}

		if (Obs != true && depth != this->Config.LookAhead){		//if this state hasnt been observed and this is NOT the top level in the lookahead
			this->BackTracks++;				//then return an error
			return 99;
		}
		else if (Obs != true && depth == this->Config.LookAhead){	//if we havent observed this state, and it IS the first step, then break out of
			break;								//of the loop, where we will return a random tile
		}
		else if (Obs == true){					//if we have observed this state, then generate the next tile
			float Norm = 0;
			Probs.resize(PT.size());
			for (int i = 0; i< PT.size(); i++)	//reset the value of Probs
				Probs[i] = 0;

			for (int a = 0; a < PT.size(); a++){
				for (int x = 0; x < this->TileTypes.size(); x++){
					if (PT.at(a) == this->TileTypes.at(x)){
						Probs[a] = this->HierProbabilities[WhichDepMat][HierTile][ID][x];
						Norm += this->HierProbabilities[WhichDepMat][HierTile][ID][x];
					}
				}
			}
			for (int i = 0; i<PT.size(); i++){						//renormalize the probabilities
				Probs[i] = Probs[i] / Norm;
			}

			//PICK THE TILE
			double PR = 0;
			int tracker = 1;
            selector = ((double)rand()/RAND_MAX);
			for (int a = 0; a<PT.size(); a++){
				PR = PR + Probs[a];
				if (Probs[a]>0)
					tracker = a;
				if (selector <= PR){
					id = a;
					break;
				}
				//if weirdness happens with the probabilities
				//BROKEN
                //if (a >= PT.size() - 1 && id == -1)
				//	id = tracker;
			}

			if (h < Map.size() && w < Map.at(0).size()){
				Map[h][w] = PT[id];
            }

			//call the GenTile function to generate the next tile
			//set to a test variable, so we can check the validity
			//of the next state
			int test = 1;

			if (depth > 0){
				if (w < this->LengthOfLevel - 1)
					test = GenerateBottomLevelTile(TileTypes, depth - 1, h, w + 1, Method, HierMap, WhichDepMat, manualConversion);
            }
			//if the next state isnt valid, remove the tile chosen in this state and try a different one
			if (test == 99){
				int j = 0;
				if (id < PT.size()){
					for (vector<char>::iterator i = PT.begin(); i != PT.end(); i++){
						if (PT.at(j) == PT.at(id)){
							PT.erase(i);
							break;
						}
						j++;
					}
				}
				else
					PT.clear();
			}
			else{
				for (int i = 0; i < this->TileTypes.size(); i++){
					if (PT[id] == this->TileTypes[i])
						return i;
				}
			}
		}
	}									//end of loop

	if (depth == this->Config.LookAhead){				//if no valid options on top level, return error code 100
		return 100;
	}
	else{
		this->BackTracks++;
		return 99;				//if no valid options on sub level, return error.
	}							//forces a different choice on upper levels.

}

void Generator::GenerateBottomLevel(string filename, string HierMapFile, int RandOffsetSeed, bool  manualConversion){

	srand((unsigned)time(0) + RandOffsetSeed);
    START =0;

	//initialize the set of possible tiles for this level
	vector<char> PossibleTiles;
    for (int i = 0; i < this->TileTypes.size(); i++)
		PossibleTiles.push_back(this->TileTypes.at(i));
    
	//initialize the map to be generated
	this->Map.resize(this->HeightOfLevel);
	for (int i = 0; i < this->HeightOfLevel; i++){
		this->Map[i].resize(this->LengthOfLevel);
		for (int j = 0; j < this->LengthOfLevel; j++){
			this->Map[i][j] = 'X';
		}
	}

	//read in the current HighLevel map
	vector< vector<char > > HierMap;
	vector<char> tmp;
	ifstream Hier;
	Hier.open(HierMapFile.c_str());
	string line = "";
	while (getline(Hier, line)){
		for (int i = 0; i < line.size(); i++)
			tmp.push_back(line.at(i));
		HierMap.push_back(tmp);
		tmp.clear();
	}

    for (int i = this->HeightOfLevel-1; i >= 0; i--){
        for (int j = 0; j < this->LengthOfLevel; j++){
            //try to generate a tile with the first config matrix
            int id = GenerateBottomLevelTile(PossibleTiles, this->Config.LookAhead, i, j, this->Config.DependencyMatrices[0], HierMap, 0,  manualConversion);
            //if it fails, and we are using a fallback strategy, try to generate with the second config matrix
            //if a good tile is generated with first method, track it
            if (id != 100){
                this->NumberTilesWithEachMatrix[0]++;
            }

            int WhichDepMat = 1;
            while (id == 100 && WhichDepMat < this->Config.NumberMatrices){

                id = GenerateBottomLevelTile(PossibleTiles, this->Config.LookAhead, i, j, this->Config.DependencyMatrices[WhichDepMat], HierMap, WhichDepMat,  manualConversion);
                //track how many tiles generated with fallback method
                if (id != 100){
                    this->NumberTilesWithEachMatrix[WhichDepMat]++;
                    break;
                }
                else
                    WhichDepMat++;
            }

            //if it also fails, or we are not using a fallback strategy, generate a tile at random
            if (id == 100){
                //ignore one of the tiles
                id = rand() % this->TileTypes.size() - 1;
                //ensure that the Start tile is not selected
                id++;
            }
            Map[i][j] = this->TileTypes.at(id);
        }
    }

	//open the file to print the map into
	ofstream GMap;
	GMap.open(filename.c_str());
	for (int i = 0; i < this->Map.size(); i++){
		for (int j = 0; j < this->Map.at(0).size(); j++){
			GMap << this->Map[i][j];
		}
		GMap << endl;
	}
    
}

void Generator::CopyProbs(string ProbsFile, bool Hier, int WhichDepMat){

	ifstream Probs, FBProbs;
	Probs.open(ProbsFile.c_str());

	if (!Hier){
		float P;
		int index = 0;
		vector< float > Tmp;

		while (Probs >> P){
			Tmp.push_back(P);
			index++;
			if (index == this->TileTypes.size()){
				index = 0;
				this->Probabilities[WhichDepMat].push_back(Tmp);
				Tmp.clear();
			}
		}
		Probs.close();

		Tmp.clear();
	}
	else{
		float P;
		int index = 0;
		int innerIndex = 0;
		vector< float > Tmp;
		vector< vector<float> > TMP;

		while (Probs >> P){
			Tmp.push_back(P);
			index++;
			if (index == this->TileTypes.size()){
				index = 0;
				TMP.push_back(Tmp);
				Tmp.clear();
				innerIndex++;
				if (innerIndex == this->Config.Rows[WhichDepMat]){
					this->HierProbabilities[WhichDepMat].push_back(TMP);
					innerIndex = 0;
					TMP.clear();
				}
			}
		}
		Probs.close();
		Tmp.clear();
	}
}

void Generator::CopyConfig(Configuration ToCopy){

    Config.DependencyMatrices.resize(ToCopy.DependencyMatrices.size());
    Config.DepComplexities.resize(ToCopy.DepComplexities.size());
    Config.Rows.resize(ToCopy.Rows.size());
 
    for (int i = 0; i < ToCopy.NumberMatrices; i++){

        Config.DependencyMatrices[i]=ToCopy.DependencyMatrices[i];
		Config.DepComplexities[i]=ToCopy.DepComplexities[i];
		Config.Rows[i]=ToCopy.Rows[i];
		Config.NumberMatrices++;
    }
    
	this->Config.height = ToCopy.height;
	this->Config.Hierarchical = ToCopy.Hierarchical;
	this->Config.LookAhead = ToCopy.LookAhead;
	this->Config.NumberTilesTypes = ToCopy.NumberTilesTypes;
	this->Config.Rowsplits = ToCopy.Rowsplits;
	this->Config.SizeOfArray = ToCopy.SizeOfArray;
	this->Config.TopDown = ToCopy.TopDown;
	this->Config.width = ToCopy.width;
    
}

Generator::Generator(int DesiredLength, int DesiredHeight){
	LengthOfLevel = DesiredLength;
    HeightOfLevel = DesiredHeight;
	BackTracks = 0;
    Config.NumberMatrices =0;
}

void Generator::SetTileTypes(vector<char> Types, bool Hier){

	if (!Hier){
		for (int i = 0; i < Types.size(); i++)
			this->TileTypes.push_back(Types.at(i));
	}
	else{
		for (int i = 0; i < Types.size(); i++)
			this->HierTileTypes.push_back(Types.at(i));

		this->START = 0;
    }
}

void Generator::SetLevelHeight(string SampleMap){

	ifstream Sample;
	Sample.open(SampleMap.c_str());
	string line = "";
	int H = 0;
	while (getline(Sample, line))
		H++;
	
	this->HeightOfLevel = H;
}

void Generator::ResizeVectors(bool Hier){

    this->Probabilities.resize(this->Config.NumberMatrices);
    if (Hier){
		this->HierProbabilities.resize(this->Config.NumberMatrices);
	}

    for (int i = 0; i < this->Config.NumberMatrices; i++){
        this->NumberTilesWithEachMatrix.push_back(0);
    }
}
